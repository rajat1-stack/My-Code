var ar=[];
var n=prompt("enter the nuber of pairs");
for(var i=0;i<n;i++)
    {
        ar[i]=prompt("eneter element"+(i+1));
    }

document.write(fun(n,ar));
function fun (n, ar) 
{
var res = 0;
    ar.sort();
    for(var i=0; i<n;i++){
        if(ar[i] == ar[i+1]){
            i++;
                  res++;
           }
    }
return res;
}




